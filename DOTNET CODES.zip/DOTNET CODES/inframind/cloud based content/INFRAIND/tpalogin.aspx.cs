﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class tpalogin : System.Web.UI.Page
{
    string upid, uppwd;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        upid = TextBox1.Text.ToUpper();
        uppwd = TextBox2.Text.ToUpper();

        if (TextBox1.Text == "")
        {
            string myStringVariable1 = string.Empty;
            myStringVariable1 = "Enter tpa id";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
        }
        else
        {
            if (TextBox2.Text == "")
            {
                string myStringVariable1 = string.Empty;
                myStringVariable1 = "Enter tpa Password";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
            }
            else
            {
                if (upid == "TPA" && uppwd == "TPA")
                {
                    Session["tpa"] = TextBox1.Text;
                    Response.Redirect("tpamain.aspx");
                }
                else
                {
                    string myStringVariable1 = string.Empty;
                    myStringVariable1 = "Enter tpa ID/Password Correcly.";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                }
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}
