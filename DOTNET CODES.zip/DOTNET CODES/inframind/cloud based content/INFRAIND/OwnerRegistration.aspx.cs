﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
//using System.Web.Mail;


public partial class OwnerRegistration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
    Class1 cs = new Class1();
    int ownerid, Securitykey = 0;
    string owrid, yes, yes1;

    protected void Page_Load(object sender, EventArgs e)
    {
        ownerid = cs.idgeneration();
        TextBox6.Text = DateTime.Now.ToShortDateString();
        TextBox3.Attributes.Add("OnKeyPress", "ValidateNumeric()");
        TextBox4.Attributes.Add("OnKeyPress", "ValidateNumeric()");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            string myStringVariable1 = string.Empty;
            myStringVariable1 = "Enter Owner ID.";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
        }
        else
        {
            if (TextBox2.Text == "")
            {
                string myStringVariable1 = string.Empty;
                myStringVariable1 = "Enter Owner Password.";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
            }
            else
            {
                if (RadioButtonList1.SelectedIndex == -1)
                {
                    string myStringVariable1 = string.Empty;
                    myStringVariable1 = "Select Gender";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                }
                else
                {
                    if (TextBox3.Text == "")
                    {
                        string myStringVariable1 = string.Empty;
                        myStringVariable1 = "Enter your age.";
                        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                    }
                    else
                    {
                        if (TextBox4.Text == "")
                        {
                            string myStringVariable1 = string.Empty;
                            myStringVariable1 = "Enter your contact number.";
                            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                        }
                        else
                        {
                            if (TextBox5.Text == "")
                            {
                                string myStringVariable1 = string.Empty;
                                myStringVariable1 = "Enter your Email ID.";
                                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                            }
                            else
                            {
                                SqlDataAdapter adp = new SqlDataAdapter("select * from Registration", con);
                                DataSet ds = new DataSet();
                                adp.Fill(ds);
                                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                {
                                    owrid = ds.Tables[0].Rows[i]["ownerid"].ToString();
                                    if (owrid == TextBox1.Text)
                                    {
                                        yes = "yes";
                                        goto Outer;
                                    }
                                    else
                                    {
                                        yes = "no";
                                    }
                                }
                            Outer:
                                yes1 = "yes";

                                if (yes != "yes")
                                {
                                    SqlCommand cmd = new SqlCommand();
                                    con.Open();
                                    cmd.Connection = con;
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.CommandText = "SPRegistration";

                                    cmd.Parameters.Add("@oid", SqlDbType.Int, 0);
                                    cmd.Parameters["@oid"].Value = ownerid;

                                    cmd.Parameters.Add("@ownerid", SqlDbType.VarChar, 50);
                                    cmd.Parameters["@ownerid"].Value = TextBox1.Text;

                                    cmd.Parameters.Add("@ownerpwd", SqlDbType.NVarChar, 50);
                                    cmd.Parameters["@ownerpwd"].Value = TextBox2.Text;

                                    cmd.Parameters.Add("@gender", SqlDbType.NVarChar, 10);
                                    cmd.Parameters["@gender"].Value = RadioButtonList1.SelectedItem.Text;

                                    cmd.Parameters.Add("@age", SqlDbType.Int, 3);
                                    cmd.Parameters["@age"].Value = TextBox3.Text;

                                    cmd.Parameters.Add("@mobile", SqlDbType.BigInt, 15);
                                    cmd.Parameters["@mobile"].Value = TextBox4.Text;

                                    cmd.Parameters.Add("@emailid", SqlDbType.NVarChar, 50);
                                    cmd.Parameters["@emailid"].Value = TextBox5.Text;

                                    cmd.Parameters.Add("@date", SqlDbType.NVarChar, 10);
                                    cmd.Parameters["@date"].Value = TextBox6.Text;

                                    cmd.Parameters.Add("@securitykey", SqlDbType.Int, 5);
                                    cmd.Parameters["@securitykey"].Value = Securitykey;

                                    cmd.ExecuteNonQuery();

                                    //NetworkCredential loginInfo = new NetworkCredential(gMailAccount, password);
                                    //MailMessage msg = new MailMessage();
                                    //msg.From = new MailAddress(gMailAccount);
                                    //msg.To.Add(new MailAddress(TextBox5.Text));
                                    //msg.Subject = subject;
                                    //msg.Body = message;
                                    //msg.IsBodyHtml = true;

                                    //SmtpClient client = new SmtpClient("smtp.gmail.com");
                                    //client.EnableSsl = true;
                                    //client.UseDefaultCredentials = false;
                                    //client.Credentials = loginInfo;
                                    //client.Send(msg);

                                    //MailMessage mail = new MailMessage();
                                    //mail.To = TextBox5.Text;
                                    //mail.From = gMailAccount;
                                    //mail.Subject = "secret key";
                                    //mail.Body = "this is my test email body";
                                    //mail.BodyFormat = MailFormat.Html;
                                    ////mail.Priority = MailPriority.Normal;
                                    //SmtpMail.SmtpServer = "localhost";  //your real server goes here
                                    //SmtpMail.Send(mail);

                                    Response.Redirect("RegisterSuccess.aspx");
                                }
                                else
                                {
                                    string myStringVariable1 = string.Empty;
                                    myStringVariable1 = "This Owner ID Already Exists.";
                                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        RadioButtonList1.SelectedIndex = -1;
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}
