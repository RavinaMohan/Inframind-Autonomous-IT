using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AdminWAP1 : System.Web.UI.MobileControls.MobilePage
{
    string ownerid;
    Class1 cs2 = new Class1();
    string constring;
    string fnerifyYES = "YES", fnerifyNO = "NO", fdownload = "Allow", fdownloadblock = "Block";

    protected void Page_Load(object sender, EventArgs e)
    {
        constring = Convert.ToString(cs2.constr());

        lblID.Text = "Welcome " + (string)Session["ownername"] + " !";

        ownerid = (string)Session["ownername"];

        SqlConnection con = new SqlConnection(constring);
        con.Open();

        if (ownerid == "ADMIN")
        {
            SqlDataAdapter adp = new SqlDataAdapter("select * from filearchive", con);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            txttot.Text = Convert.ToString(ds.Tables[0].Rows.Count);

            SqlDataAdapter adp1 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyYES + "'", con);
            DataSet ds1 = new DataSet();
            adp1.Fill(ds1);
            TextBox1.Text = Convert.ToString(ds1.Tables[0].Rows.Count);

            SqlDataAdapter adp2 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyNO + "'", con);
            DataSet ds2 = new DataSet();
            adp2.Fill(ds2);
            TextBox2.Text = Convert.ToString(ds2.Tables[0].Rows.Count);

            SqlDataAdapter adp3 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyYES + "' and fdownload='" + fdownloadblock + "'", con);
            DataSet ds3 = new DataSet();
            adp3.Fill(ds3);
            TextBox3.Text = Convert.ToString(ds3.Tables[0].Rows.Count);

            SqlDataAdapter adp4 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyYES + "' and fdownload='" + fdownload + "'", con);
            DataSet ds4 = new DataSet();
            adp4.Fill(ds4);
            TextBox4.Text = Convert.ToString(ds4.Tables[0].Rows.Count);

            SqlDataAdapter adp5 = new SqlDataAdapter("select * from filearchivemodify", con);
            DataSet ds5 = new DataSet();
            adp5.Fill(ds5);
            TextBox5.Text = Convert.ToString(ds5.Tables[0].Rows.Count);
        }
        else
        {
            SqlDataAdapter adp6 = new SqlDataAdapter("select * from filearchive where fowner='" + (string)Session["ownername"] + "'", con);
            DataSet ds6 = new DataSet();
            adp6.Fill(ds6);
            txttot.Text = Convert.ToString(ds6.Tables[0].Rows.Count);

            SqlDataAdapter adp7 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyYES + "' and fowner='" + (string)Session["ownername"] + "'", con);
            DataSet ds7 = new DataSet();
            adp7.Fill(ds7);
            TextBox1.Text = Convert.ToString(ds7.Tables[0].Rows.Count);

            SqlDataAdapter adp8 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyNO + "' and fowner='" + (string)Session["ownername"] + "'", con);
            DataSet ds8 = new DataSet();
            adp8.Fill(ds8);
            TextBox2.Text = Convert.ToString(ds8.Tables[0].Rows.Count);

            SqlDataAdapter adp9 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyYES + "' and fdownload='" + fdownloadblock + "' and fowner='" + (string)Session["ownername"] + "'", con);
            DataSet ds9 = new DataSet();
            adp9.Fill(ds9);
            TextBox3.Text = Convert.ToString(ds9.Tables[0].Rows.Count);

            SqlDataAdapter adp10 = new SqlDataAdapter("select * from filearchive where fverify='" + fnerifyYES + "' and fdownload='" + fdownload + "' and fowner='" + (string)Session["ownername"] + "'", con);
            DataSet ds10 = new DataSet();
            adp10.Fill(ds10);
            TextBox4.Text = Convert.ToString(ds10.Tables[0].Rows.Count);

            SqlDataAdapter adp11 = new SqlDataAdapter("select * from filearchivemodify where fowner='" + (string)Session["ownername"] + "'", con);
            DataSet ds11 = new DataSet();
            adp11.Fill(ds11);
            TextBox5.Text = Convert.ToString(ds11.Tables[0].Rows.Count);
        }
    }
}
