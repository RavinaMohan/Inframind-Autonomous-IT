﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
    string id, id1;
    int eid, eid1;

	public Class1()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int idgeneration()
    {
        con.Open();
        SqlCommand c1 = new SqlCommand("select max(oid) from Registration", con);
        id = Convert.ToString(c1.ExecuteScalar());
        if (id == "")
        {
            eid = 1;
        }
        else
        {
            eid = Convert.ToInt16(id);
            eid = eid + 1;
        }
        con.Close();
        return eid;
    }

    public int idgeneration1()
    {
        con.Open();
        SqlCommand c1 = new SqlCommand("select max(fid) from filearchive", con);
        id1 = Convert.ToString(c1.ExecuteScalar());
        if (id1 == "")
        {
            eid1 = 1;
        }
        else
        {
            eid1 = Convert.ToInt16(id1);
            eid1 = eid1 + 1;
        }
        con.Close();
        return eid1;
    }

    public string constr()
    {
        string Constr = con.ConnectionString;
        return Constr;
    }
}
