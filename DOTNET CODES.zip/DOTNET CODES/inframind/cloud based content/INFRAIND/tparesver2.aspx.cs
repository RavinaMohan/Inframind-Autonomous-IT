﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;

public partial class tparesver2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
    Cryptography cg = new Cryptography();
    string fileid, deckey;
    string filepat, filetype, filenam;

    protected void Page_Load(object sender, EventArgs e)
    {
        fileid = (string)Session["FileIDD"];
        TextBox1.Text = (string)Session["fenccryptokey"];
        TextBox1.ReadOnly = true;
        btn1.Enabled = false;
        btnverify.Enabled = false;
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("tparesver.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        //SqlDataAdapter adp = new SqlDataAdapter("select * from filearchive where fid='" + (string)Session["FileIDD"] + "'", con);
        //DataSet ds = new DataSet();
        //adp.Fill(ds);
        deckey= Convert.ToString(cg.Decrypt(TextBox1.Text));
        Session["deckey"] = deckey;
        string myStringVariable1 = string.Empty;
        TextBox1.ReadOnly = false;
        myStringVariable1 = "Decrypted Cryptographic Key is :" + cg.Decrypt(TextBox1.Text);
        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string deckey1 = (string)Session["deckey"];
        if (deckey1 == TextBox2.Text)
        {
            btn1.Enabled = true;
            btnverify.Enabled = true;
            TextBox1.ReadOnly = true;
        }
        else
        {
            btn1.Enabled = false;
        }
    }


    protected void btn1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select * from filearchive where fid = '" + (string)Session["FileIDD"] + "'", con);
        DataTable dt = GetData(cmd);
        if (dt != null)
        {
            download(dt);
        }
        //SqlDataAdapter adp = new SqlDataAdapter("select * from filearchive where fid='" + (string)Session["FileIDD"] + "'", con);
        //DataSet ds = new DataSet();
        //adp.Fill(ds);

        //filepat = ds.Tables[0].Rows[0]["filepath"].ToString();
        //filetype = ds.Tables[0].Rows[0]["fext"].ToString();
        //filenam = ds.Tables[0].Rows[0]["ffilename"].ToString();

        //if (IsPostBack)
        //{
        //    string filepath = filepat;

        //    string filename = Path.GetFileName(filepath);
        //    System.IO.Stream stream = null;
        //    try
        //    {
        //        stream = new FileStream(filepath, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read);
        //        //// Total bytes to read: 
        //        long bytesToRead = stream.Length;
        //        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        //        //if(ext=
        //        switch (filetype)
        //        {
        //            case ".pdf":
        //                Response.ContentType = "application/pdf";
        //                break;
        //            case ".jpg":
        //                Response.ContentType = "application/jpg";
        //                break;
        //            case ".edg":
        //                Response.ContentType = "application/edg";
        //                break;
        //            case ".doc":
        //                Response.ContentType = "application/msword";
        //                break;
        //            case ".ppt":
        //                Response.ContentType = "application/ppt";
        //                break;
        //            case ".gif":
        //                Response.ContentType = "application/gif";
        //                break;
        //            case ".zip":
        //                Response.ContentType = "application/zip";
        //                break;
        //            case ".ico":
        //                Response.ContentType = "application/ico";
        //                break;
        //            case ".xls":
        //            case ".csv":
        //                Response.ContentType = "application/xls";
        //                break;
        //            case ".htm":
        //            case ".html":
        //                Response.ContentType = "text/html";
        //                break;
        //            case ".txt":
        //                Response.ContentType = "text/plain";
        //                break;

        //            default:
        //                Response.ContentType = "application/octet-stream";
        //                break;
        //        }
        //        //Response.ContentType = "application/msword";
        //        Response.AddHeader("Content-Disposition", "attachment; filename=" + filename);
        //        // Read the bytes from the stream in small portions. 
        //        while (bytesToRead > 0)
        //        {
        //            // Make sure the client is still connected. 
        //            if (Response.IsClientConnected)
        //            {
        //                // Read the data into the buffer and write into the 
        //                // output stream. 
        //                byte[] buffer = new Byte[1000];
        //                int length = stream.Read(buffer, 0, 1000);
        //                Response.OutputStream.Write(buffer, 0, length);
        //                Response.Flush();
        //                // We have already read some bytes.. need to read 
        //                // only the remaining. 
        //                bytesToRead = bytesToRead - length;
        //            }
        //            else
        //            {
        //                // Get out of the loop, if user is not connected anymore.. 
        //                bytesToRead = -1;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Response.Write(ex.Message);
        //        // An error occurred.. 
        //    }
        //    finally
        //    {
        //        if (stream != null)
        //        {
        //            stream.Close();
        //        }
        //    }
        //}

    }

    private DataTable GetData(SqlCommand cmd)
    {

        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            return dt;
        }
        catch
        {
            return null;
        }

        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
        }
    }

    private void download(DataTable dt)
    {

        Byte[] bytes = (Byte[])dt.Rows[0]["filebytes"];
        Response.Buffer = true;
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //ftype = dt.Rows[0]["filetype"].ToString();
        //Response.ContentType = "application/"+ ftype+" ";
        Response.ContentType = dt.Rows[0]["fext"].ToString();
        Response.AddHeader("content-disposition", "attachment;filename=" + dt.Rows[0]["ffilename"].ToString());
        //Response.BinaryWrite("<script type='text/javascript'> <embed src='bytes' style=width:300px; height:200px;> </embed> </script> ");
        Response.BinaryWrite(bytes);
        Response.Flush();
        Response.End();
    } 

    protected void btnverify_Click(object sender, EventArgs e)
    {
        Response.Redirect("tparesver3.aspx");
    }
}
