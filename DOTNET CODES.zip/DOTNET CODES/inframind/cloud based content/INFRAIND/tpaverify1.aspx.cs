﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class tpaverify1 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
    string fileid, keyrequest = "YES";

    protected void Page_Load(object sender, EventArgs e)
    {
        fileid = (string)Request.Params["ID"];
        Session["FileID"] = fileid;
        SqlDataAdapter adp = new SqlDataAdapter("Select * from filearchive where fid='" + fileid + "'", con);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        Label4.Text = ds.Tables[0].Rows[0]["fid"].ToString();
        Label7.Text = ds.Tables[0].Rows[0]["ffilename"].ToString();
        Label10.Text = ds.Tables[0].Rows[0]["fsubject"].ToString();
        Label13.Text = ds.Tables[0].Rows[0]["fext"].ToString();
        Label16.Text = ds.Tables[0].Rows[0]["fsizeinkb"].ToString();
        Label19.Text = ds.Tables[0].Rows[0]["fdatetime"].ToString();
        Label23.Text = ds.Tables[0].Rows[0]["fverify"].ToString();
        Label29.Text = ds.Tables[0].Rows[0]["keyrequest"].ToString();
        if (Label23.Text == "YES" || Label29.Text == "YES")
        {
            Button1.Enabled = false;
            Button2.Enabled = false;
            if (Label23.Text == "YES")
            {
                string myStringVariable1 = string.Empty;
                myStringVariable1 = "File already verified.";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
            }
            else
            {
                if (Label23.Text == "NO" && Label29.Text == "YES")
                {
                    string myStringVariable1 = string.Empty;
                    myStringVariable1 = "This file request for key proceesing.";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                }
            }
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("tpaverify.aspx");
    }

    protected void btnyes_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd1 = new SqlCommand("update filearchive set keyrequest='" + keyrequest + "' where fid='" + Label4.Text + "'", con);
        cmd1.ExecuteNonQuery();
        con.Close();

        Label25.Text = "Cryptography Key Request Sent To Owner.";
        Label25.ForeColor = System.Drawing.ColorTranslator.FromHtml("#088A08");
        btnyes.Visible = false;
        btnno.Visible = false;
        Button1.Enabled = false;
        Label24.Visible = true;
        Button2.Enabled = false;
        
        ModalPopupExtender1.Show();
        Panel3.Visible = true;
    }

    protected void btnno_Click(object sender, EventArgs e)
    {
        Page_Load(null, EventArgs.Empty);
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Page_Load(null, EventArgs.Empty);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("tpadirectvermod.aspx");
    }
}
