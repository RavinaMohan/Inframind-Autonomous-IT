using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class AdminWAP : System.Web.UI.MobileControls.MobilePage
{
    Class1 cs1 = new Class1();
    string upid, uppwd, constring;
    string yes, yes1, s;

    protected void Page_Load(object sender, EventArgs e)
    {
        constring = Convert.ToString(cs1.constr());
    }

    protected void cmd1submit(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(constring);
        con.Open();

        upid = txtid.Text.ToUpper();
        uppwd = txtpwd.Text.ToUpper();

        if (upid == "ADMIN" && uppwd == "ADMIN")
        {
            Session["ownername"] = upid;
            Response.Redirect("AdminWAP1.aspx");
            //Session["AdminID"] = TextBox1.Text;
        }
        else
        {
            SqlDataAdapter adp = new SqlDataAdapter("select * from Registration", con);
            DataSet ds = new DataSet();
            adp.Fill(ds);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                upid = ds.Tables[0].Rows[i]["ownerid"].ToString();
                uppwd = ds.Tables[0].Rows[i]["ownerpwd"].ToString();

                if (upid == txtid.Text && uppwd == txtpwd.Text)
                {
                    Session["ownername"] = txtid.Text;
                    yes = "yes";
                    goto Outer;
                }
                else
                {
                    yes1 = "yes";
                }
            }
        Outer:
            s = "s";
                        
        }

        if (yes == "yes")
        {
            Response.Redirect("AdminWAP1.aspx");
        }
        else
        {
            Response.Redirect("AdminWAPError.aspx");
        }
    }
}
