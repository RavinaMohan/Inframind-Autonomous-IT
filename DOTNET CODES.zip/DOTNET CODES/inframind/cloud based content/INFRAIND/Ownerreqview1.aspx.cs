﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Ownerreqview1 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
    string fileid, fdownload = "Allow";

    protected void Page_Load(object sender, EventArgs e)
    {
        fileid = Request.Params["ID"];
        SqlDataAdapter adp = new SqlDataAdapter("Select * from filearchive where fid='" + fileid + "'", con);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        Label4.Text = ds.Tables[0].Rows[0]["fid"].ToString();
        Label7.Text = ds.Tables[0].Rows[0]["ffilename"].ToString();
        Label10.Text = ds.Tables[0].Rows[0]["fsubject"].ToString();
        Label13.Text = ds.Tables[0].Rows[0]["fext"].ToString();
        Label16.Text = ds.Tables[0].Rows[0]["fsizeinkb"].ToString();
        Label19.Text = ds.Tables[0].Rows[0]["fdatetime"].ToString();
        Label23.Text = ds.Tables[0].Rows[0]["fverify"].ToString();
        Label29.Text = ds.Tables[0].Rows[0]["fenccryptokey"].ToString();
        Label26.Text = ds.Tables[0].Rows[0]["fdownload"].ToString();

        if (Label26.Text == "Allow")
        {
            string myStringVariable1 = string.Empty;
            myStringVariable1 = "Cryptographic Key Already Sent To TPA.";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
            Button1.Enabled = false;
        }
        else
        {
            //
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Ownerreqview.aspx");
    }
    protected void btnfinish_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("update filearchive set fdownload='" + fdownload + "' where fid='" + Label4.Text + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {

    }
}
