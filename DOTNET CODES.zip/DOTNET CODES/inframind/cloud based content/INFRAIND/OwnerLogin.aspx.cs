﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;

public partial class OwnerLogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
    string owrid, owrpwd, yes;

    string gMailAccount = "skkingslinarunkumar@gmail.com";
    string password = "kingkumar";
    string to;
    string subject = "secret key for login";
    string message;
    string Securitykey;
    string ranno;

    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox3.Attributes.Add("OnKeyPress", "ValidateNumeric()");
        //Button1.Attributes.Add("onclick", "window.open('securitykeywindow.aspx','','height=300,width=300');return false");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            string myStringVariable1 = string.Empty;
            myStringVariable1 = "Enter Owner ID";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
        }
        else
        {
            if (TextBox2.Text == "")
            {
                string myStringVariable1 = string.Empty;
                myStringVariable1 = "Enter Owner Password";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
            }
            else
            {
                SqlDataAdapter adp = new SqlDataAdapter("select * from Registration", con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    owrid = ds.Tables[0].Rows[i]["ownerid"].ToString();
                    owrpwd = ds.Tables[0].Rows[i]["ownerpwd"].ToString();
                    if (TextBox1.Text == owrid && TextBox2.Text == owrpwd)
                    {
                         yes = "yes";
                    }
                }
                if (yes == "yes")
                {
                    Session["ownerid"] = TextBox1.Text;
                    //Response.Redirect("OwnerMain.aspx");
                    Panel2.Visible = true;
                    //this.Button1.Attributes.Add("onclick", "javascript:return OpenPopup()");
                    //onClick="genericPopup(this.href,300,300,no)"
                    //Response.Write("<script>window.close()</script>");
                }
                else
                {
                    string myStringVariable1 = string.Empty;
                    myStringVariable1 = "Enter OwnerID/Password Correctly.";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                }
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Securitykey = (string)Session["rendomnum"];
        if (TextBox3.Text == Securitykey)
        {
            Session.Remove("rendomnum");
            Response.Redirect("OwnerMain.aspx");
        }
        else
        {
            TextBox3.Text = "";
            //Response.Redirect("OwnerLogin.aspx");
            string myStringVariable1 = string.Empty;
            myStringVariable1 = "You are not authenticated. Plz try again once.";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        TextBox3.Text = "";
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Panel2.Visible = false;
        Label4.Visible = false;
        Label5.Visible = false;
        TextBox3.Visible = false;
        Button3.Visible = false;
        Button4.Visible = false;
        Button6.Visible = true;
        Response.Redirect("OwnerLogin.aspx");
        //Button1_Click(null, EventArgs.Empty);
    }
    //protected void Button5_Click(object sender, EventArgs e)
    //{

    //}
    protected void Button6_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "")
        {
            string myStringVariable1 = string.Empty;
            myStringVariable1 = "Enter Owner ID";
            ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
        }
        else
        {
            if (TextBox2.Text == "")
            {
                string myStringVariable1 = string.Empty;
                myStringVariable1 = "Enter Owner Password";
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
            }
            else
            {
                SqlDataAdapter adp = new SqlDataAdapter("select * from Registration", con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    owrid = ds.Tables[0].Rows[i]["ownerid"].ToString();
                    owrpwd = ds.Tables[0].Rows[i]["ownerpwd"].ToString();
                    if (TextBox1.Text == owrid && TextBox2.Text == owrpwd)
                    {
                        Random val = new Random();
                        int rno = val.Next(12345, 54321);
                        ranno = Convert.ToString(rno);

                        Session["rendomnum"] = ranno;

                        con.Open();
                        SqlCommand cmd = new SqlCommand("update Registration set securitykey='" + ranno + "'where ownerid='" + owrid + "'", con);
                        cmd.ExecuteNonQuery();
                        con.Close();

                        message = "<hr><br>Hello " + "<b>" + owrid + " ! </b><br><br>" + "Your Login Security Key is : " + "<b>" + ranno + "</b>";
                        to = ds.Tables[0].Rows[i]["emailid"].ToString();
                        NetworkCredential loginInfo = new NetworkCredential(gMailAccount, password);
                        MailMessage msg = new MailMessage();
                        msg.From = new MailAddress(gMailAccount);
                        msg.To.Add(new MailAddress(to));
                        msg.Subject = subject;
                        msg.Body = message;
                        msg.IsBodyHtml = true;

                        try
                        {
                            SmtpClient client = new SmtpClient("smtp.gmail.com");
                            client.EnableSsl = true;
                            client.UseDefaultCredentials = false;
                            client.Credentials = loginInfo;
                            client.Send(msg);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex);
                            Label4.Text = "OFFLINE : Failure Sending Mail !";
                            LinkButton1.Visible = true;
                        }

                        yes = "yes";
                    }
                }
                if (yes == "yes")
                {
                    //Button1_Click(null, EventArgs.Empty);
                    Session["ownerid"] = TextBox1.Text;
                    //Response.Redirect("OwnerMain.aspx");
                    Panel2.Visible = true;
                    Label4.Visible = true;
                    TextBox3.Visible = true;
                    Label5.Visible = true;
                    Button3.Visible = true;
                    Button4.Visible = true;
                    Button6.Visible = false;
                    ModalPopupExtender1.PopupControlID = "Panel2";
                    ModalPopupExtender1.OkControlID = "Button1";
                    ModalPopupExtender1.TargetControlID = "Button1";
                    ModalPopupExtender1.Show();
                    //ModalPopupExtender1.OkControlID = "Button6";
                    //this.Button1.Attributes.Add("onclick", "javascript:return OpenPopup()");
                    //onClick="genericPopup(this.href,300,300,no)"
                    //Response.Write("<script>window.close()</script>");
                }
                else
                {
                    //Label4.Text = "Enter OwnerID/Password Correctly.";
                    //Label4.Visible = true;
                    string myStringVariable1 = string.Empty;
                    myStringVariable1 = "Enter OwnerID/Password Correctly.";
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
                }
            }
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Panel2.Visible = true;
        Label4.Visible = true;
        TextBox3.Visible = true;
        Label5.Visible = true;
        Button3.Visible = true;
        Button4.Visible = true;
        Button6.Visible = false;
        ModalPopupExtender1.PopupControlID = "Panel2";
        ModalPopupExtender1.OkControlID = "Button1";
        ModalPopupExtender1.TargetControlID = "Button1";
        ModalPopupExtender1.Show();

        string myStringVariable1 = string.Empty;
        myStringVariable1 = "Your Login Security Key is : " + (string)Session["rendomnum"];
        ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + myStringVariable1 + "');", true);
    }
}
